export function imglouder() {
    return new Promise(resolve => {
        window.onload = () => {
            resolve(true);
        }
    })
}





